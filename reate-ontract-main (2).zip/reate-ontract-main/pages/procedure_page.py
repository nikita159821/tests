import time
from enum import Enum

from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
import datetime


from locators.procedure_page_locators import LocatorsProcedure
from pages.requirement_page import RequirementPage
from tests.tests_create_procedure_page.data import PURCHASE_NAME, PLANNED_PRICE, SEARCH_CATEGORY, PAYMENT_TERMS, \
    DELIVERY_TERMS, YEAR, PRICE


class ProcedurePage(RequirementPage):
    def __init__(self, browser):
        super().__init__(browser)
        self.procedure_url = None

    # Нажимаем продолжить на странице создания процедуры
    def click_button_resume(self):
        self.wait_for_all_loaders_to_disappear()
        # 1. Открываем выпадающий список
        self.click_element(LocatorsProcedure.CHOOSING_PURCHASE)
        self.wait_for_visible_and_clickable(LocatorsProcedure.CHOOSING_PURCHASE)
        # 2. Находим элемент select
        input_element = self.find_element(LocatorsProcedure.CHOOSING_PURCHASE)
        # 3. Выбираем процедуру закупки
        input_element.send_keys(Keys.ARROW_DOWN)
        input_element.send_keys(Keys.ENTER)
        # 5. Нажимаем "Продолжить"
        self.wait_for_visible_and_clickable(LocatorsProcedure.BUTTON_RESUME)
        self.click_element(LocatorsProcedure.BUTTON_RESUME)

    # убираем чек-бокс "Документы."
    def click_remove_checkbox_docs(self):
        self.wait_for_visible_and_clickable(LocatorsProcedure.REMOVE_CHECKBOX)
        self.click_element(LocatorsProcedure.REMOVE_CHECKBOX)

    # Скроллим и нажимаем продолжить
    def click_create_next_button(self):
        element = self.find_element(LocatorsProcedure.CREATE_NEXT_BUTTON)
        self.browser.execute_script("arguments[0].scrollIntoView(true);", element)
        self.click_element(LocatorsProcedure.CREATE_NEXT_BUTTON)
        self.wait_for_visible_and_clickable(LocatorsProcedure.INPUT_DATE_END)

    # Вводим дату в поле "Окончание подачи заявок"
    def click_input_date_end(self):
        global YEAR  # Обозначаем YEAR как глобальную
        # Получаем текущий год
        current_year = datetime.datetime.now().year
        # Если YEAR меньше или равен текущему году, добавляем 5 лет
        if int(YEAR) <= current_year:
            YEAR = str(int(YEAR) + 5)
        self.click_element(LocatorsProcedure.INPUT_DATE_END)
        self.send_keys_text_of_element(LocatorsProcedure.YEAR_BEGIN, YEAR)
        self.click_element(LocatorsProcedure.DATE_BEGIN_AND_YEAR_END)
        self.wait_for_visible_and_clickable(LocatorsProcedure.INPUT_PLANE_DATE_END)

    # Вводим дату в поле "Окончание загрузки документов"
    def click_input_plane_date_end(self):
        self.click_element(LocatorsProcedure.INPUT_PLANE_DATE_END)
        self.send_keys_text_of_element(LocatorsProcedure.PLANE_YEAR_BEGIN, '2050')
        self.click_element(LocatorsProcedure.PLANE_DATE_BEGIN_AND_YEAR_END)

    # Выключаем тогл "Необходимо согласование публикации"
    def disable_approval_toggle(self):
        element = self.find_element(LocatorsProcedure.TOGGLE_OFF_APPROVAL_PUBLICATION)
        self.browser.execute_script("arguments[0].scrollIntoView(true);", element)
        self.click_element(LocatorsProcedure.TOGGLE_OFF_APPROVAL_PUBLICATION)

    # Выключаем тогл "Необходимо согласование проекта итогов"
    def disable_project_approval_toggle(self):
        self.click_element(LocatorsProcedure.TOGGLE_OFF_PROJECT_APPROVAL)

    # Выключаем тогл "Необходимо согласование публикации итогов"
    def disable_publication_approval_toggle(self):
        self.click_element(LocatorsProcedure.TOGGLE_OFF_PUBLICATION_APPROVAL)

    # Вводим "Название закупки"
    def send_keys_text_purchase_name(self):
        element = self.find_element(LocatorsProcedure.INPUT_PURCHASE_NAME)
        self.browser.execute_script("arguments[0].scrollIntoView(true);", element)
        self.send_keys_text_of_element(LocatorsProcedure.INPUT_PURCHASE_NAME, PURCHASE_NAME)

    # Нажимаем на поле "Тип процедуры"
    def click_select_purchase_type_procedure(self):
        self.click_element(LocatorsProcedure.SELECT_PROCEDURE_TYPE)
        self.choosing_purchase_type_procedure()

    # Выбираем "Тип процедуры"
    def choosing_purchase_type_procedure(self):
        # 2. Находим элемент
        input_element = self.find_element(LocatorsProcedure.SELECT_PROCEDURE_TYPE)
        # 3. Выбираем "Тип процедуры"
        input_element.send_keys(Keys.ARROW_DOWN)
        input_element.send_keys(Keys.ENTER)

    # Вводим данные в поле "Плановая стоимость, ₽ (без НДС)"
    def send_keys_text_planned_input(self):
        self.send_keys_text_of_element(LocatorsProcedure.PLANNED_INPUT, PLANNED_PRICE)

    # Нажимаем кнопку "Выбрать категорию ОКПД2"
    def clik_button_classifier_category(self):
        self.click_element(LocatorsProcedure.BUTTON_CLASSIFIER_CATEGORY)
        self.wait_element_to_be_clickable(LocatorsProcedure.INPUT_SEARCH_CATEGORY)

    # Вводим категорию в поиск
    def send_keys_text_search_category(self):
        self.send_keys_text_of_element(LocatorsProcedure.INPUT_SEARCH_CATEGORY, SEARCH_CATEGORY)
        self.wait_element_to_be_clickable(LocatorsProcedure.CHOOSING_CATEGORY)

    # Выбираем введенную категорию
    def choosing_category(self):
        self.click_element(LocatorsProcedure.CHOOSING_CATEGORY)
        self.wait_element_to_be_clickable(LocatorsProcedure.MODAL_CONFIRM_BUTTON)

    # Подтверждаем выбранную категорию
    def click_modal_confirm_button(self):
        self.wait_element_to_be_clickable(LocatorsProcedure.MODAL_CONFIRM_BUTTON)
        self.click_element(LocatorsProcedure.MODAL_CONFIRM_BUTTON)

    # Общий метод для выбора категории ОКПД2
    def select_okpd2_category(self):
        self.clik_button_classifier_category()
        self.send_keys_text_search_category()
        self.choosing_category()
        self.click_modal_confirm_button()

    # Вводим данные в поле "Условия оплаты"
    def send_keys_text_payment_terms(self):
        self.wait_element_to_be_clickable(LocatorsProcedure.INPUT_PAYMENT_TERMS)
        self.send_keys_text_of_element(LocatorsProcedure.INPUT_PAYMENT_TERMS, PAYMENT_TERMS)

    # Вводим данные в поле "Условия поставки / оказания услуг"
    def send_keys_text_delivery_terms(self):
        self.wait_element_to_be_clickable(LocatorsProcedure.INPUT_DELIVERY_TERMS)
        self.send_keys_text_of_element(LocatorsProcedure.INPUT_DELIVERY_TERMS, DELIVERY_TERMS)

    # Нажимаем на поле "Адрес поставки"
    def click_select_purchase_address_supplies(self):
        element = self.find_element(LocatorsProcedure.ADDRESS_SUPPLIES)
        self.browser.execute_script("arguments[0].scrollIntoView(true);", element)
        self.click_element(LocatorsProcedure.ADDRESS_SUPPLIES)
        self.choosing_purchase_address_supplies()

    # Выбираем "Адрес поставки"
    def choosing_purchase_address_supplies(self):
        # 2. Находим элемент
        input_element = self.find_element(LocatorsProcedure.ADDRESS_SUPPLIES)
        # 3. Выбираем "Тип процедуры"
        input_element.send_keys(Keys.ARROW_DOWN)
        input_element.send_keys(Keys.ENTER)

    def click_next_button(self, wait=None):
        element = self.find_element(LocatorsProcedure.CREATE_NEXT_BUTTON)
        self.browser.execute_script("arguments[0].scrollIntoView(true);", element)
        self.click_element(LocatorsProcedure.CREATE_NEXT_BUTTON)
        if wait:
            self.wait_for_visible_and_clickable(wait)

    # Ожидаем загрузки раздела "Дополнительные поля" и нажимаем "Продолжить"
    def scroll_additional_field(self):
        element = self.find_element(LocatorsProcedure.ADDITIONAL_FIELD_NAME)
        self.browser.execute_script("arguments[0].scrollIntoView(true);", element)
        self.click_element(LocatorsProcedure.CREATE_NEXT_BUTTON)
        self.wait_for_visible_and_clickable(LocatorsProcedure.ALTERNATE_CHECKBOX)

    # Ожидаем загрузки раздела "Заявка" и нажимаем "Продолжить"
    def scroll_alternate_checkbox(self):
        element = self.find_element(LocatorsProcedure.ALTERNATE_CHECKBOX)
        self.browser.execute_script("arguments[0].scrollIntoView(true);", element)
        self.click_element(LocatorsProcedure.CREATE_NEXT_BUTTON)
        self.wait_for_visible_and_clickable(LocatorsProcedure.TRADE_ID)

    # Объединенный метод для нажатия кнопки и ожидания загрузки
    def click_create_next_button_and_scroll(self):
        self.click_next_button(LocatorsProcedure.ADDITIONAL_FIELD_NAME)
        self.scroll_additional_field()
        self.scroll_alternate_checkbox()
        self.wait_for_visible_and_clickable(LocatorsProcedure.PUBLISH_TRADE_BUTTON)

    # Нажимаем "Войти" на странице процедуры
    def click_sign_in_btn(self):
        self.wait_for_visible_and_clickable(LocatorsProcedure.SIGN_IN_BTN)
        self.click_element(LocatorsProcedure.SIGN_IN_BTN)

    # Нажимаем кнопку "Опубликовать процедуру"
    def get_and_publish_trade(self):
        self.click_element(LocatorsProcedure.PUBLISH_TRADE_BUTTON)
        self.wait_for_visible_and_clickable(LocatorsProcedure.MODAL_CONFIRM_BUTTON)
        # Нажимаем кнопку "Опубликовать в модальном окне"
        self.click_modal_confirm_button()
        self.wait_for_all_loaders_to_disappear()
        # Сохраняем URL процедуры
        self.procedure_url = self.get_current_url()

    # Выходим из лк инициатора. И авторизуемся поставщиком
    def authorization_supplier(self):
        self.click_element(LocatorsProcedure.EXIT_BUTTON_LK)
        self.click_sign_in_btn()
        self.login_and_password_supplies()

    # Нажимаем кнопку "Подать заявку" поставщиком
    def click_send_offer_button(self):
        self.wait_for_visible_and_clickable(LocatorsProcedure.SEND_OFFER_BUTTON)
        self.click_close_cookies()
        self.wait_for_visible_and_clickable(LocatorsProcedure.SEND_OFFER_BUTTON)
        self.click_element(LocatorsProcedure.SEND_OFFER_BUTTON)
        self.wait_for_visible_and_clickable(LocatorsProcedure.FORM_SAVE_BUTTON)

    # Нажимаем кнопку "Сохранить и продолжить"
    def click_form_save_button(self):
        self.click_element(LocatorsProcedure.FORM_SAVE_BUTTON)

    # Выбираем позицию для подачи заявки
    def choose_position_application(self):
        self.wait_for_visible_and_clickable(LocatorsProcedure.POSITION_APPLICATION)
        self.click_element(LocatorsProcedure.POSITION_APPLICATION)

    # Указываем цену за единицу НДС в сайдбаре
    def send_keys_text_price_value_input(self):
        self.wait_for_visible_and_clickable(LocatorsProcedure.PRICE_VALUE_INPUT)
        self.send_keys_text_of_element(LocatorsProcedure.PRICE_VALUE_INPUT, PRICE)

    # Закрываем окно с куками
    def click_close_cookies(self):
        self.click_element(LocatorsProcedure.CLOSE_COOKIES)

    # Нажимаем "Сохранить" при подаче заявки на процедуру и отправляем заявку
    def save_position_and_submit_application(self):
        self.wait_for_visible_and_clickable(LocatorsProcedure.SAVE_POSITION_BUTTON)
        self.click_element(LocatorsProcedure.SAVE_POSITION_BUTTON)
        self.wait_for_visible_and_clickable(LocatorsProcedure.SAVE_POSITION_BUTTON)
        self.click_element(LocatorsProcedure.SAVE_POSITION_BUTTON)
        self.wait_for_visible_and_clickable(LocatorsProcedure.POSITION_APPLICATION)
        self.click_element(LocatorsProcedure.CREATE_NEXT_BUTTON)
        time.sleep(2)
        element = self.find_element(LocatorsProcedure.CREATE_NEXT_BUTTON)
        self.browser.execute_script("arguments[0].scrollIntoView(true);", element)
        self.click_element(LocatorsProcedure.CREATE_NEXT_BUTTON)

    # Выходим из ЛК
    def logout_lk(self):
        self.wait_for_all_loaders_to_disappear()
        self.click_element(LocatorsProcedure.LOGOUT)

    # Заходим админом в процедуру
    def login_admin_procedure(self):
        self.wait_for_visible_and_clickable(LocatorsProcedure.HEADER_LOGIN_BUTTON)
        self.click_element(LocatorsProcedure.HEADER_LOGIN_BUTTON)
        self.login_and_password_admin()
        self.wait_for_visible_and_clickable(LocatorsProcedure.HEADER_LOGOUT)
        self.open(self.procedure_url)

    # редактируем процедуру
    def edit_procedure(self):
        self.wait_for_visible_and_clickable(LocatorsProcedure.EDIT_TRADE_BUTTON)
        self.click_element(LocatorsProcedure.EDIT_TRADE_BUTTON)

    # Нажимаем чек-бокс "Завершить прием заявок сейчас"
    def click_finish_accepting_applications_checkbox(self):
        self.wait_for_visible_and_clickable(LocatorsProcedure.LOCATOR_FINISH_ACCEPTING_APPLICATIONS_CHECKBOX)
        self.click_element(LocatorsProcedure.LOCATOR_FINISH_ACCEPTING_APPLICATIONS_CHECKBOX)

    # Нажимаем кнопку "Сохранить изменения"
    def click_save_changes_button(self):
        self.click_element(LocatorsProcedure.SAVE_CHANGES_BUTTON)
        # подтверждаем изменения
        self.wait_for_visible_and_clickable(LocatorsProcedure.MODAL_CONFIRM_BUTTON)
        self.click_modal_confirm_button()

    # Заходим закупщиком в процедуру
    def sign_in_purchaser_to_procedure(self):
        self.wait_for_visible_and_clickable(LocatorsProcedure.EDIT_TRADE_BUTTON)
        self.click_element(LocatorsProcedure.EXIT_BUTTON_LK)
        self.wait_for_all_loaders_to_disappear()
        self.click_element(LocatorsProcedure.LOGIN_LK)
        self.login_and_password_purchaser()

    # Нажимаем "Рассмотреть заявки"
    def click_review_applications(self):
        self.wait_element_to_be_clickable(LocatorsProcedure.CREATE_OFFER_ADMITTANCES)
        self.click_element(LocatorsProcedure.CREATE_OFFER_ADMITTANCES)

    # Нажимаем "Утвердить рассмотрение"
    def click_coordination_confirm_changes(self):
        self.wait_for_visible_and_clickable(LocatorsProcedure.COORDINATION_CONFIRM_CHANGES)
        self.click_element(LocatorsProcedure.COORDINATION_CONFIRM_CHANGES)
        self.click_modal_confirm_button()

    # Нажимаем на таб "Извещение"
    def click_notice_tab_in_shadow_dom(self):
        # 1.  Находим trade-header-widget и получаем Shadow Root
        self.wait_for_visible_and_clickable(LocatorsProcedure.TRADE_HEADER_WIDGET)
        offers_page_widget = self.find_element(LocatorsProcedure.TRADE_HEADER_WIDGET)
        shadow_root = self.browser.execute_script('return arguments[0].shadowRoot', offers_page_widget)

        # 2. Ждем, пока таб "Извещение" станет кликабельным *внутри* Shadow DOM
        self.wait_for_visible_and_clickable_in_shadow_dom(shadow_root, LocatorsProcedure.NOTICE_TAB_BUTTON.value[1])

        # 3. Находим и кликаем на таб "Извещение" ВНУТРИ Shadow DOM
        notice_tab_button = shadow_root.find_element(By.CSS_SELECTOR, LocatorsProcedure.NOTICE_TAB_BUTTON.value[1])
        self.click_element(notice_tab_button)

    # Нажимаем "Подвести итоги"
    def click_create_results_button(self):
        self.wait_for_visible_and_clickable(LocatorsProcedure.CREATE_RESULTS_BUTTON)
        self.click_element(LocatorsProcedure.CREATE_RESULTS_BUTTON)
        self.click_modal_confirm_button()

    # Выбираем срок действия решения по процедуре и сохраняем
    def choice_time_procedure(self):
        self.wait_for_visible_and_clickable(LocatorsProcedure.WINNERS_SELECT)
        start_date_and_date_end = self.get_current_date_string()
        self.send_keys_text_of_element(LocatorsProcedure.START_DATE_PERIOD_BEGIN_LOCATOR, start_date_and_date_end)
        self.send_keys_text_of_element(LocatorsProcedure.END_DATE_PERIOD_BEGIN_LOCATOR, start_date_and_date_end)
        self.click_modal_confirm_button()

    # Публикуем итоги
    def publish_result(self):
        self.click_modal_confirm_button()

    # Нажимает кнопку "Создать документ"
    def click_create_document(self):
        self.wait_for_visible_and_clickable(LocatorsProcedure.CREATE_DOCUMENT)
        self.click_element(LocatorsProcedure.CREATE_DOCUMENT)
