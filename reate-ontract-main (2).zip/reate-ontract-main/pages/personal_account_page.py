import os
import keyboard
import time
from dotenv import load_dotenv

from locators.main_page_locators import LocatorsLk
from pages.main_page import MainPage
from tests.tests_create_contract_page.urls import URL
from tests.tests_create_request_page.data import UPLOAD_FILE_1_2
from tests.tests_create_request_page.urls import BETA_PGK_ALTIS, MAIN, MAIN_NEXT


class PersonalPage(MainPage):
    def __init__(self, browser):
        super().__init__(browser)
        load_dotenv()  # Загружаем переменные окружения
        self.login_pkg = os.environ.get('LOGIN_PKG')
        self.password_pkg = os.environ.get('PASSWORD_PGK')
        self.login_pkg_coordinat = os.environ.get('LOGIN_PKG_COORDINAT')
        self.password_pkg_coordinat = os.environ.get('PASSWORD_PGK_COORDINAT')
        self.login_analytpribor = os.environ.get('LOGIN_ANALYTPRIBOR')
        self.password_analytpribor = os.environ.get('PASSWORD_ANALYTPRIBOR')
        self.current_url = None

    # Авторизация инициатором
    def authorize_iniciator_and_open_lk(self):
        # Открываем главную страницу
        self.open(f'{URL}')
        self.login_button()
        self.login_input_send_keys(self.login_pkg)
        self.password_input_send_keys(self.password_pkg)
        self.click_enter_button()
        self.wait_for_page_load(f'{URL}{MAIN_NEXT}')
        self.open(f'{BETA_PGK_ALTIS}')

    # Авторизация поставщиком
    def authorize_supplier_and_open_lk(self, ):
        # Открываем главную страницу
        self.open(f'{URL}')
        self.browser.refresh()
        self.login_button()
        self.login_input_send_keys(self.login_pkg_coordinat)
        self.password_input_send_keys(self.password_pkg_coordinat)
        self.click_enter_button()
        self.wait_for_page_load(f'{URL}{MAIN}')
        self.open(self.current_url)
        self.wait_for_visible_and_clickable(LocatorsLk.BUTTON_APPROVAL)

    # Нажимаем кнопку "Создать заявку"
    def click_button_create_request(self):
        self.wait_for_visible_and_clickable(LocatorsLk.BUTTON_CREATE_REQUEST)
        self.click_element(LocatorsLk.BUTTON_CREATE_REQUEST)

    # Нажимаем кнопку "Список позиций"
    def click_button_list_positions(self):
        self.wait_for_visible_and_clickable(LocatorsLk.BUTTON_LIST_POSITIONS)
        self.click_element(LocatorsLk.BUTTON_LIST_POSITIONS)

    # Нажимаем кнопку "Загрузить из файла"
    def click_button_upload_file(self):
        self.wait_for_visible_and_clickable(LocatorsLk.BUTTON_UPLOAD_FILE)
        self.click_element(LocatorsLk.BUTTON_UPLOAD_FILE)

    @staticmethod
    def upload_file_1_2():
        time.sleep(0.7)  # Задержка, чтобы дать время переключиться на нужное окно
        keyboard.write(UPLOAD_FILE_1_2)  # Ввод текста
        keyboard.press_and_release('enter')  # Нажатие клавиши Enter
        time.sleep(2)

    # Нажимаем кнопку "Отправить на согласование"
    def click_button_send_approval(self):
        self.wait_for_visible_and_clickable(LocatorsLk.BUTTON_SEND_APPROVAL)
        self.click_element(LocatorsLk.BUTTON_SEND_APPROVAL)
        self.click_button_send()

    # Нажимаем кнопку "Отправить"
    def click_button_send(self):
        self.wait_for_visible_and_clickable(LocatorsLk.BUTTON_SEND)
        self.click_element(LocatorsLk.BUTTON_SEND)
        self.wait_for_visible_and_clickable(LocatorsLk.EXIT_BUTTON_LK)

    # Сохраняем url страницы с заявкой
    def save_url_application(self):
        self.current_url = self.get_current_url()
        return self.current_url

    # Выходи из ЛК и авторизовываемся поставщиком
    def exit_lk(self):
        self.save_url_application()
        self.click_element(LocatorsLk.EXIT_BUTTON_LK)
        self.authorize_supplier_and_open_lk()

    # Нажимаем кнопку "Согласовать"
    def click_button_approval(self):
        self.click_element(LocatorsLk.BUTTON_APPROVAL)
        self.wait_for_visible_and_clickable(LocatorsLk.BUTTON_APPROVAL_FORM)

    # Нажимаем кнопку "Согласовать" в форме подтверждения
    def click_button_approval_form(self):
        self.click_element(LocatorsLk.BUTTON_APPROVAL_FORM)