from locators.contact_page_locators import LocatorsAgreement
from pages.base_page import BasePage
from tests.tests_create_contract_page.data import REMOTECONTRACT_SETDOCUMENTFILE, REMOTE_CONTRACT_SET_DOCUMENT_STATUS
from tests.tests_create_contract_page.urls import URL, WEB_SERVICE


class WebServicePage(BasePage):
    def __init__(self, browser):
        super().__init__(browser)

    # Вставляем данные для запроса в веб сервис
    def change_code_mirror_content(self, new_text):
        js_script = """
              var codeMirror = document.querySelector('.CodeMirror').CodeMirror;
              codeMirror.setValue(arguments[0]);
              """
        self.browser.execute_script(js_script, new_text)

    # Метод для передачи файла в веб сервис
    def prepare_xml_data(self, contract_id, contract_external_id):
        return REMOTECONTRACT_SETDOCUMENTFILE.format(contract_id=contract_id, contract_external_id=contract_external_id)

    # Метод для передачи статуса в веб сервис
    def prepare_xml_data_status(self, status, contract_id, contract_external_id):
        return REMOTE_CONTRACT_SET_DOCUMENT_STATUS.format(contract_id=contract_id,
                                                          contract_external_id=contract_external_id, status=status)

    # Нажимает кнопку отправить запрос в веб сервисе
    def click_button_request_web_service(self):
        # Скролл до элемента
        element = self.wait_presence_of_element_located(LocatorsAgreement.BUTTON_REQUEST_WEB_SERVICE)
        self.browser.execute_script("arguments[0].scrollIntoView(true);", element)
        self.click_element(LocatorsAgreement.BUTTON_REQUEST_WEB_SERVICE)

    def perform_web_service_action(self, xml_data):
        self.wait_for_visible_and_clickable(LocatorsAgreement.BUTTON_REQUEST_WEB_SERVICE)
        self.change_code_mirror_content(xml_data)
        self.click_button_request_web_service()
