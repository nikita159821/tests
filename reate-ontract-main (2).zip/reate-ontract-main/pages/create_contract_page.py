import time

from locators.contact_page_locators import LocatorsBasicInformation, LocatorsBlockAttributes, \
    LocatorsBlockAdditionalAttributes, LocatorsAgreement
from pages.base_page import BasePage
from pages.main_page import MainPage
from pages.web_service_page import WebServicePage
from tests.tests_create_contract_page.data import CONTRACTOR, DOCUMENT_TYPE, NAME_DOCUMENT, PRICE_DOCUMENT_WITHOUT_VAT, \
    RCM_SIGN_PLACE, BEGIN_YEAR, END_YEAR, STATUS_REMOTE_CONTRACT_APPROVED, STATUS_REMOTE_CONTRACT_ACTIVATED
from tests.tests_create_contract_page.urls import URL, URL_DOCUMENT, WEB_SERVICE


class ContractPage(BasePage):
    def __init__(self, browser):
        super().__init__(browser)

    # Нажимаем кнопку "создать документ"
    def click_button_create_documents(self):
        self.wait_for_visible_and_clickable(LocatorsBasicInformation.BUTTON_CREATE_DOCUMENTS)
        self.click_element(LocatorsBasicInformation.BUTTON_CREATE_DOCUMENTS)
        self.wait_for_all_loaders_to_disappear()

    # Переключаемся на вкладку и вводим контрагента
    def send_keys_contractor(self):
        self.switch_to_window(1)
        self.wait_for_visible_and_clickable(LocatorsBasicInformation.INPUT_CONTRACTOR)
        self.send_keys_text_of_element(LocatorsBasicInformation.INPUT_CONTRACTOR, CONTRACTOR)
        time.sleep(2)
        self.click_element(LocatorsBasicInformation.CHOICE_INPUT_CONTRACTOR)

    # Выбираем тип документа
    def choice_document_type(self):
        self.wait_for_visible_and_clickable(LocatorsBasicInformation.DOCUMENT_TYPE)
        self.send_keys_text_of_element(LocatorsBasicInformation.DOCUMENT_TYPE, DOCUMENT_TYPE)
        self.wait_for_visible_and_clickable(LocatorsBasicInformation.CHOICE_DOCUMENT_TYPE)
        self.click_element(LocatorsBasicInformation.CHOICE_DOCUMENT_TYPE)

    # Выбираем значение в поле "процесс"
    def choice_process(self):
        self.wait_for_visible_and_clickable(LocatorsBasicInformation.PROCESS)
        self.click_element(LocatorsBasicInformation.PROCESS)
        self.wait_for_visible_and_clickable(LocatorsBasicInformation.CHOICE_PROCESS)
        self.click_element(LocatorsBasicInformation.CHOICE_PROCESS)

    # Выбираем шаблон поставщика
    def click_template_supplier(self):
        # Скролл до элемента
        element = self.wait_presence_of_element_located(LocatorsBasicInformation.TEMPLATE_SUPPLIER)
        self.browser.execute_script("arguments[0].scrollIntoView(true);", element)
        self.click_element(LocatorsBasicInformation.TEMPLATE_SUPPLIER)

    # Нажимаем кнопку "Продолжить"
    def click_button_resume(self):
        self.click_element(LocatorsBasicInformation.BUTTON_RESUME)

    # Вводим название документа
    def send_keys_name_document(self):
        self.wait_for_visible_and_clickable(LocatorsBlockAttributes.NAME_DOCUMENT)
        self.send_keys_text_of_element(LocatorsBlockAttributes.NAME_DOCUMENT, NAME_DOCUMENT)

    # Выбираем группу закупок
    def choice_purchasing_group(self):
        self.wait_for_visible_and_clickable(LocatorsBlockAttributes.PURCHASING_GROUP)
        self.click_element(LocatorsBlockAttributes.PURCHASING_GROUP)
        self.wait_for_visible_and_clickable(LocatorsBlockAttributes.CHOICE_PURCHASING_GROUP)
        self.click_element(LocatorsBlockAttributes.CHOICE_PURCHASING_GROUP)

    # Вводим стоимость без НДС
    def send_keys_price_document_without_vat(self):
        self.send_keys_text_of_element(LocatorsBlockAttributes.PRICE_DOCUMENT_WITHOUT_VAT, PRICE_DOCUMENT_WITHOUT_VAT)

    # Выбираем условия оплаты
    def choice_payment_terms(self):
        # Скролл до элемента
        element = self.wait_presence_of_element_located(LocatorsBlockAttributes.PAYMENT_TERMS)
        self.browser.execute_script("arguments[0].scrollIntoView(true);", element)
        self.click_element(LocatorsBlockAttributes.PAYMENT_TERMS)
        self.wait_for_visible_and_clickable(LocatorsBlockAttributes.PAYMENT_TERMS)
        self.click_element(LocatorsBlockAttributes.CHOICE_PAYMENT_TERMS)

    # Выбираем валюту стоимости
    def choice_value_currency(self):
        self.wait_for_visible_and_clickable(LocatorsBlockAttributes.VALUE_CURRENCY)
        self.click_element(LocatorsBlockAttributes.VALUE_CURRENCY)
        self.wait_for_visible_and_clickable(LocatorsBlockAttributes.CHOICE_VALUE_CURRENCY)
        self.click_element(LocatorsBlockAttributes.CHOICE_VALUE_CURRENCY)

    # Выбираем дату начала действия документа
    def choice_date_begin(self):
        self.wait_for_visible_and_clickable(LocatorsBlockAttributes.DATE_BEGIN)
        self.click_element(LocatorsBlockAttributes.DATE_BEGIN)
        self.send_keys_text_of_element(LocatorsBlockAttributes.YEAR_BEGIN, BEGIN_YEAR)
        self.click_element(LocatorsBlockAttributes.DATE_BEGIN_AND_YEAR_END)

    # Выбираем дату окончания действия документа
    def choice_date_end(self):
        self.wait_for_visible_and_clickable(LocatorsBlockAttributes.DATE_END)
        self.click_element(LocatorsBlockAttributes.DATE_END)
        self.send_keys_text_of_element(LocatorsBlockAttributes.YEAR_END, END_YEAR)
        self.click_element(LocatorsBlockAttributes.DATE_END_AND_YEAR_END)

    # Нажимаем "Продолжить" в разделе "Атрибуты"
    def click_button_resume_page_attributes(self):
        self.click_element(LocatorsBlockAttributes.BUTTON_RESUME_PAGE_ATTRIBUTES)

    # Выбираем Вид договора
    def choice_type_agreement(self):
        self.wait_for_visible_and_clickable(LocatorsBlockAdditionalAttributes.TYPE_AGREEMENT)
        self.click_element(LocatorsBlockAdditionalAttributes.TYPE_AGREEMENT)
        self.wait_for_visible_and_clickable(LocatorsBlockAdditionalAttributes.CHOICE_TYPE_AGREEMENT)
        self.click_element(LocatorsBlockAdditionalAttributes.CHOICE_TYPE_AGREEMENT)

    # Выбираем Автопролонгацию
    def choice_auto_renewal_category_code(self):
        self.wait_for_visible_and_clickable(LocatorsBlockAdditionalAttributes.AUTO_RENEWAL_CATEGORY_CODE)
        self.click_element(LocatorsBlockAdditionalAttributes.AUTO_RENEWAL_CATEGORY_CODE)
        self.wait_for_visible_and_clickable(LocatorsBlockAdditionalAttributes.CHOICE_AUTO_RENEWAL_CATEGORY_CODE)
        self.click_element(LocatorsBlockAdditionalAttributes.CHOICE_AUTO_RENEWAL_CATEGORY_CODE)
        # Скролл до элемента
        element = self.wait_presence_of_element_located(LocatorsBlockAdditionalAttributes.RCM_TYPE_SUMM)
        self.browser.execute_script("arguments[0].scrollIntoView(true);", element)

    # Выбираем Тип суммы договора
    def choice_rcm_type_summ(self):
        self.wait_for_visible_and_clickable(LocatorsBlockAdditionalAttributes.RCM_TYPE_SUMM)
        self.click_element(LocatorsBlockAdditionalAttributes.RCM_TYPE_SUMM)
        self.wait_for_visible_and_clickable(LocatorsBlockAdditionalAttributes.CHOICE_RCM_TYPE_SUMM)
        self.click_element(LocatorsBlockAdditionalAttributes.CHOICE_RCM_TYPE_SUMM)

    # Выбираем Место подписания документа
    def send_keys_rcm_sign_place(self):
        self.wait_for_visible_and_clickable(LocatorsBlockAdditionalAttributes.RCM_SIGN_PLACE)
        self.send_keys_text_of_element(LocatorsBlockAdditionalAttributes.RCM_SIGN_PLACE, RCM_SIGN_PLACE)

    # Выбираем Фиксированный валютный курс
    def choice_is_fixed_currency(self):
        self.click_element(LocatorsBlockAdditionalAttributes.CHOICE_IS_FIXED_CURRENCY)

    # Выбираем Категория ДД
    def choice_contract_category_code(self):
        self.click_element(LocatorsBlockAdditionalAttributes.CONTRACT_CATEGORY_CODE)
        self.wait_for_visible_and_clickable(LocatorsBlockAdditionalAttributes.CHOICE_CONTRACT_CATEGORY_CODE)
        self.click_element(LocatorsBlockAdditionalAttributes.CHOICE_CONTRACT_CATEGORY_CODE)

    # Выбираем Подкатегория ДД
    def choice_rcm_sub_categ(self):
        # Скролл до элемента
        element = self.wait_presence_of_element_located(LocatorsBlockAdditionalAttributes.RCM_SUB_CATEG)
        self.browser.execute_script("arguments[0].scrollIntoView(true);", element)
        self.click_element(LocatorsBlockAdditionalAttributes.RCM_SUB_CATEG)
        self.wait_for_visible_and_clickable(LocatorsBlockAdditionalAttributes.CHOICE_RCM_SUB_CATEG)

        self.click_element(LocatorsBlockAdditionalAttributes.CHOICE_RCM_SUB_CATEG)

    # Выбираем Бизнес-сферу
    def choice_business_area_code(self):
        self.click_element(LocatorsBlockAdditionalAttributes.BUSINESS_AREA_CODE)
        self.wait_for_visible_and_clickable(LocatorsBlockAdditionalAttributes.CHOICE_BUSINESS_AREA_CODE)
        self.click_element(LocatorsBlockAdditionalAttributes.CHOICE_BUSINESS_AREA_CODE)

    # Выбираем ПФМ
    def choice_financial_management_position(self):
        self.click_element(LocatorsBlockAdditionalAttributes.FINANCIAL_MANAGEMENT_POSITION)
        self.wait_for_visible_and_clickable(LocatorsBlockAdditionalAttributes.CHOICE_FINANCIAL_MANAGEMENT_POSITION)
        self.click_element(LocatorsBlockAdditionalAttributes.CHOICE_FINANCIAL_MANAGEMENT_POSITION)

    # Выбираем Вид деятельности
    def choice_activity_category(self):
        self.click_element(LocatorsBlockAdditionalAttributes.ACTIVITY_CATEGORY)
        self.wait_for_visible_and_clickable(LocatorsBlockAdditionalAttributes.CHOICE_ACTIVITY_CATEGORY)
        self.click_element(LocatorsBlockAdditionalAttributes.CHOICE_ACTIVITY_CATEGORY)

    # Выбираем Договор ЦА филиалы
    def choice_rcm_subs_id(self):
        self.click_element(LocatorsBlockAdditionalAttributes.CHOICE_RCM_SUBS_ID)

    # Выбираем Реквизиты Банка АО “ПГК”
    def choice_house_bank(self):
        self.click_element(LocatorsBlockAdditionalAttributes.HOUSE_BANK)
        self.wait_for_visible_and_clickable(LocatorsBlockAdditionalAttributes.CHOICE_HOUSE_BANK)
        self.click_element(LocatorsBlockAdditionalAttributes.CHOICE_HOUSE_BANK)

    # Выбираем Идентификатор счета
    def choice_account_details_id(self):
        self.click_element(LocatorsBlockAdditionalAttributes.ACCOUNT_DETAILS_ID)
        self.wait_for_visible_and_clickable(LocatorsBlockAdditionalAttributes.CHOICE_ACCOUNT_DETAILS_ID)
        self.click_element(LocatorsBlockAdditionalAttributes.CHOICE_ACCOUNT_DETAILS_ID)

    # Выбираем Период акта сверки
    def choice_rcm_act_period(self):
        self.click_element(LocatorsBlockAdditionalAttributes.RCM_ACT_PERIOD)
        self.wait_for_visible_and_clickable(LocatorsBlockAdditionalAttributes.CHOICE_RCM_ACT_PERIOD)
        self.click_element(LocatorsBlockAdditionalAttributes.CHOICE_RCM_ACT_PERIOD)

    # Нажимаем "Продолжить" в разделе "Дополнительные Атрибуты"
    def click_button_resume_page_additional_attributes(self):
        self.click_element(LocatorsBlockAdditionalAttributes.BUTTON_RESUME_PAGE_ADDITIONAL_ATTRIBUTES)

    # Нажимаем "Продолжить" в разделе "Документ"
    def click_button_resume_page_document(self):
        self.wait_for_visible_and_clickable(LocatorsBlockAdditionalAttributes.BUTTON_RESUME_PAGE_DOCUMENT)
        self.click_element(LocatorsBlockAdditionalAttributes.BUTTON_RESUME_PAGE_DOCUMENT)
        time.sleep(0.7)

    # Нажимаем "Создать документ" в разделе "Согласование"
    def click_button_create_document_page_agreement(self):
        self.wait_for_visible_and_clickable(LocatorsBlockAdditionalAttributes.BUTTON_CREATE_DOCUMENT_PAGE_AGREEMENT)
        self.click_element(LocatorsBlockAdditionalAttributes.BUTTON_CREATE_DOCUMENT_PAGE_AGREEMENT)

    # Нажимаем "Отправить" в сайдбаре
    def click_button_to_send_page_agreement(self):
        self.wait_for_visible_and_clickable(LocatorsBlockAdditionalAttributes.BUTTON_TO_SEND_PAGE_AGREEMENT)
        self.click_element(LocatorsBlockAdditionalAttributes.BUTTON_TO_SEND_PAGE_AGREEMENT)

    # Нажимаем "Отправить документ в SAP
    def click_button_agreement(self):
        self.wait_for_visible_and_clickable(LocatorsAgreement.BLOCK_AGREEMENT)
        self.click_element(LocatorsAgreement.BLOCK_AGREEMENT)

    # Получаем номер документа в КМ
    def extract_id_from_url(self):
        url_contract_id = self.get_current_url()
        parts = url_contract_id.split('/')
        contract_id = parts[-2]
        return contract_id

    # Нажимаем "Согласовать документ" поставщиком и отправляем закупщику
    def click_button_approve_document(self):
        self.wait_for_visible_and_clickable(LocatorsAgreement.BUTTON_APPROVE_DOCUMENT)
        self.click_element(LocatorsAgreement.BUTTON_APPROVE_DOCUMENT)
        self.wait_for_visible_and_clickable(LocatorsAgreement.BUTTON_SEND)
        self.click_element(LocatorsAgreement.BUTTON_SEND)


class ContractBasicInformation(ContractPage):
    def block_basic_information(self):
        self.send_keys_contractor()
        self.choice_document_type()
        self.choice_process()
        self.click_template_supplier()
        self.click_button_resume()


class ContractBlockAttributes(ContractPage):
    def block_attributes(self):
        self.send_keys_name_document()
        self.choice_purchasing_group()
        self.send_keys_price_document_without_vat()
        self.choice_payment_terms()
        self.choice_value_currency()
        self.choice_date_begin()
        self.choice_date_end()
        self.click_button_resume_page_attributes()


class ContractBlockAdditionalAttributes(ContractPage):
    def block_additional_attributes(self):
        self.choice_type_agreement()
        self.choice_auto_renewal_category_code()
        self.choice_rcm_type_summ()
        self.send_keys_rcm_sign_place()
        self.choice_is_fixed_currency()
        self.choice_contract_category_code()
        self.choice_rcm_sub_categ()
        self.choice_business_area_code()
        self.choice_financial_management_position()
        self.choice_activity_category()
        self.choice_rcm_subs_id()
        self.choice_house_bank()
        self.choice_account_details_id()
        self.choice_rcm_act_period()
        self.click_button_resume_page_additional_attributes()


class ContractBlockAgreement(ContractPage, WebServicePage):
    def block_agreement_and_block_signing(self):
        main = MainPage(self.browser)
        self.click_button_agreement()
        # Извлекаем ID контракта из URL текущей страницы
        contract_id = self.extract_id_from_url()
        self.open(f'{URL}{WEB_SERVICE}')
        # Готовим XML для отправки через веб-сервис (устанавливаем ID контракта).
        contract_id_xml = self.prepare_xml_data(contract_id, contract_id)
        # Отправляем подготовленный XML через веб-сервис, изменяя его значение через CodeMirror
        self.perform_web_service_action(contract_id_xml)
        # Готовим XML для установки статуса "Согласован" через веб-сервис.
        status_approved_xml = self.prepare_xml_data_status(STATUS_REMOTE_CONTRACT_APPROVED, contract_id, contract_id)
        # Отправляем подготовленный XML со статусом "Согласован" через веб-сервис
        self.perform_web_service_action(status_approved_xml)
        main.exit_and_login_supplier()
        self.open(f'{URL}{URL_DOCUMENT}{contract_id}')
        self.click_button_approve_document()
        main.exit_and_login_purchaser()
        # Готовим XML для установки статуса "Активирован" через веб-сервис.
        status_activated_xml = self.prepare_xml_data_status(STATUS_REMOTE_CONTRACT_ACTIVATED, contract_id, contract_id)
        # Отправляем подготовленный XML со статусом "Активирован" через веб-сервис
        self.perform_web_service_action(status_activated_xml)
        self.open(f'{URL}{URL_DOCUMENT}{contract_id}')
