import os

from dotenv import load_dotenv
from pages.base_page import BasePage
from locators.main_page_locators import *
from tests.tests_create_contract_page.urls import URL, CONTRACT, WEB_SERVICE


class MainPage(BasePage):
    def __init__(self, browser):
        super().__init__(browser)
        load_dotenv()  # Загружаем переменные окружения
        self.login_pkg = os.environ.get('LOGIN_PKG')
        self.password_pkg = os.environ.get('PASSWORD_PGK')
        self.login_analytpribor = os.environ.get('LOGIN_ANALYTPRIBOR')
        self.password_analytpribor = os.environ.get('PASSWORD_ANALYTPRIBOR')

    # Нажимаем на кнопку на главной "Войти"
    def login_button(self):
        self.wait_for_all_loaders_to_disappear()
        self.click_element(LocatorsAuth.LOGIN_BUTTON)
        self.wait_for_visible_and_clickable(LocatorsAuth.LOGIN_INPUT)

    # Возвращает поле логин
    def get_login_input(self):
        return self.find_element(LocatorsAuth.LOGIN_INPUT)

    # Вводим логин
    def login_input_send_keys(self, login_pkg):
        self.wait_for_visible_and_clickable(LocatorsAuth.LOGIN_INPUT)
        self.get_login_input().send_keys(login_pkg)

    # Возвращает поле пароль
    def get_password_input(self):
        return self.find_element(LocatorsAuth.PASSWORD_INPUT)

    # Вводим пароль
    def password_input_send_keys(self, password_pkg):
        self.get_password_input().send_keys(password_pkg)

    # Нажимаем кнопку "Войти" после ввода данных авторизации
    def click_enter_button(self):
        self.wait_for_visible_and_clickable(LocatorsAuth.ENTER_BUTTON)
        self.click_element(LocatorsAuth.ENTER_BUTTON)

    # Выходим из акк.и заходим под поставщиком
    def exit_and_login_supplier(self):
        self.open(f'{URL}')
        self.wait_for_all_loaders_to_disappear()
        self.click_element(LocatorsAuth.EXIT_BUTTON)
        self.login_input_send_keys(self.login_analytpribor)
        self.password_input_send_keys(self.password_analytpribor)
        self.click_enter_button()
        self.open(f'{URL}{WEB_SERVICE}')

    # Выходим из акк.и заходим под закупщиком
    def exit_and_login_purchaser(self):
        self.open(f'{URL}')
        self.wait_for_all_loaders_to_disappear()
        self.click_element(LocatorsAuth.EXIT_BUTTON)
        self.login_input_send_keys(self.login_pkg)
        self.password_input_send_keys(self.password_pkg)
        self.click_enter_button()
        self.open(f'{URL}{WEB_SERVICE}')
        self.browser.refresh()

    # Объединённый метод для входа в ЛК
    def authorization(self):
        self.open(URL)
        self.login_button()
        self.login_input_send_keys(self.login_pkg)
        self.password_input_send_keys(self.password_pkg)
        self.click_enter_button()
        self.open(f'{URL}{CONTRACT}')
        self.wait_for_page_load(f'{URL}{CONTRACT}')
