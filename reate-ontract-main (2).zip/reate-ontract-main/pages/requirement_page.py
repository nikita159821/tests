import os

from locators.main_page_locators import LocatorsLk
from locators.procedure_page_locators import LocatorsProcedure
from locators.requirement_page_locators import LocatorsRequirement
from dotenv import load_dotenv
from selenium.webdriver.common.keys import Keys

from pages.main_page import MainPage
from tests.tests_create_procedure_page.urls import RP_URL
from tests.tests_create_request_page.data import RESPONSIBLE_LOGIN
from tests.tests_create_request_page.urls import URL


class RequirementPage(MainPage):
    def __init__(self, browser):
        super().__init__(browser)
        load_dotenv()  # Загружаем переменные окружения
        self.login_pkg = os.environ.get('LOGIN_PKG')
        self.password_pkg = os.environ.get('PASSWORD_PGK')
        self.login_pkg_coordinat = os.environ.get('LOGIN_PKG_COORDINAT')
        self.password_pkg_coordinat = os.environ.get('PASSWORD_PGK_COORDINAT')
        self.login_analytpribor = os.environ.get('LOGIN_ANALYTPRIBOR')
        self.password_analytpribor = os.environ.get('PASSWORD_ANALYTPRIBOR')

    # Обрабатываем номер заявки
    @staticmethod
    def split_application(expected_application_number):
        return expected_application_number.split('/')[-2].strip('/')

    def authorize_with_credentials(self, login, password):
        """Общая логика авторизации без выхода из аккаунта."""
        self.click_element(LocatorsProcedure.HEADER_LOGIN_BUTTON)
        self.login_input_send_keys(login)
        self.password_input_send_keys(password)
        self.click_enter_button()

    # Выход из лк поставщика и авторизация инициатором
    def authorization_initiator(self):
        self.click_element(LocatorsLk.EXIT_BUTTON_LK)
        self.open(f'{URL}')
        self.wait_for_visible_and_clickable(LocatorsProcedure.HEADER_LOGIN_BUTTON)
        self.authorize_with_credentials(self.login_pkg, self.password_pkg)
        self.open(f'{RP_URL}]')
        self.wait_for_visible_and_clickable(LocatorsRequirement.GET_NUMBER_APPLICATION)

    # Находим ранее созданную заявку и выбираем строку.
    def choice_line_requirement(self, expected_application_number):
        application = self.split_application(expected_application_number)
        self.authorization_initiator()
        actual_number = self.find_element(LocatorsRequirement.GET_NUMBER_APPLICATION)
        application_number = self.get_attribute_of_element(actual_number, 'title')

        if application_number == application:
            self.click_element(LocatorsRequirement.GET_ACTUAL_NUMBER_APPLICATION)
        else:
            # Выбрасываем исключение при несоответствии
            raise ValueError(
                f'Expected application number "{application}" does not match actual number "{application_number}".')

    # Открываем сайдбар строки потребности
    def open_sidebar_and_choice_responsible(self):
        self.click_element(LocatorsRequirement.OPEN_SIDEBAR)

    # Закрываем сайдбар
    def sidebar_close(self):
        self.click_element(LocatorsRequirement.CLOSE_SIDEBAR)
        self.wait_for_visible_and_clickable(LocatorsRequirement.ACTION_MENU)

    # Нажимаем на выпадающий список "Выбор действия"
    def click_button_action_menu(self):
        self.click_element(LocatorsRequirement.ACTION_MENU)

    # Нажимаем кнопку "Отправить в процедуру"
    def click_button_send_procedure(self):
        self.click_button_action_menu()
        self.wait_for_visible_and_clickable(LocatorsRequirement.BUTTON_SEND_PROCEDURE)
        self.click_element(LocatorsRequirement.BUTTON_SEND_PROCEDURE)

    # Возвращает поле с ответственным
    def get_input_responsible(self):
        input_element = self.find_element(LocatorsRequirement.RESPONSIBLE)
        return input_element

    # Выбираем ответственного
    def choice_responsible_and_send_procedure(self):
        self.open_sidebar_and_choice_responsible()
        element = self.find_element(LocatorsRequirement.SCROLL_RESPONSIBLE)
        self.browser.execute_script("arguments[0].scrollIntoView(true);", element)
        self.wait_for_visible_and_clickable(LocatorsRequirement.RESPONSIBLE)
        self.click_element(LocatorsRequirement.RESPONSIBLE)
        # Получаем элемент поля ввода
        input_element = self.find_element(LocatorsRequirement.RESPONSIBLE)
        input_element.send_keys(Keys.CONTROL + "a")  # Выделяем все
        input_element.send_keys(Keys.DELETE)  # Удаляем все
        self.get_input_responsible().send_keys(RESPONSIBLE_LOGIN)
        # Подтверждаем выбор ответственного
        self.click_element(LocatorsRequirement.CHOICE_RESPONSIBLE)
        self.sidebar_close()
        self.click_button_send_procedure()
        self.wait_for_visible_and_clickable(LocatorsProcedure.BUTTON_RESUME)
