import time

from dotenv import load_dotenv
from selenium.common import TimeoutException
from selenium.webdriver import ActionChains, Keys
from selenium.webdriver.common.by import By
from selenium.webdriver.remote.webelement import WebElement
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from enum import Enum
import os
import datetime

from locators.main_page_locators import LocatorsAuth


class BasePage:
    def __init__(self, browser):
        self.browser = browser
        self.actions = ActionChains(self.browser)
        self.original_window = self.browser.current_window_handle
        load_dotenv()  # Загружаем переменные окружения
        self.login_pkg = os.environ.get('LOGIN_PKG')
        self.password_pkg = os.environ.get('PASSWORD_PGK')
        self.login_analytpribor = os.environ.get('LOGIN_ANALYTPRIBOR')
        self.password_analytpribor = os.environ.get('PASSWORD_ANALYTPRIBOR')
        self.login_admin = os.environ.get('LOGIN_ADMIN')
        self.password_admin = os.environ.get('PASSWORD_ADMIN')

    def wait_for_element(self, locator: Enum, timeout: int = 15):
        """Waits for an element to be present on the page."""
        wait = WebDriverWait(self.browser, timeout)
        return wait.until(EC.presence_of_element_located(locator.value))

    def find_element(self, locator: Enum):
        by, value = locator.value
        return self.browser.find_element(by, value)

    def find_elements(self, locator: Enum) -> list:
        by, value = locator.value
        return self.browser.find_elements(by, value)

    def find(self, locator: Enum):
        return self.find_element(locator)

    def click_element(self, locator): #Убрали Enum
        if isinstance(locator, WebElement):
            locator.click()  # Кликаем на WebElement напрямую
        elif isinstance(locator, Enum):
            element = self.find_element(locator)
            element.click()  # Ищем WebElement по Enum и кликаем
        else:
            raise TypeError("locator must be a WebElement or Enum")

    def click_enter_element(self, locator: Enum) -> None:
        element = self.find(locator)
        element.send_keys(Keys.ENTER)

    def get_text_of_element(self, locator: Enum) -> str:
        element = self.find(locator)
        return element.text

    def send_keys_text_of_element(self, locator: Enum, text: str) -> None:
        element = self.find(locator)
        element.clear()
        element.send_keys(text)

    def wait_element_to_be_clickable(self, locator: Enum, timeout: int = 20) -> WebElement:
        WebDriverWait(self.browser, timeout).until(EC.element_to_be_clickable(locator.value))
        return self.browser.find_element(*locator.value)

    def wait_presence_of_element_located(self, locator: Enum, timeout: int = 20) -> WebElement:
        WebDriverWait(self.browser, timeout).until(EC.invisibility_of_element_located(locator.value))
        return self.browser.find_element(*locator.value)

    def wait_for_visible_and_clickable(self, locator: Enum, timeout=1000):
        try:
            element = WebDriverWait(self.browser, timeout).until(
                EC.presence_of_element_located(locator.value) and
                EC.visibility_of_element_located(locator.value) and
                EC.element_to_be_clickable(locator.value)
            )
            return element
        except TimeoutException:
            return None

    def wait_for_visible_and_clickable_in_shadow_dom(self, shadow_root, locator, timeout=10):
        """Ожидает, пока элемент станет видимым и кликабельным внутри Shadow DOM"""
        WebDriverWait(self.browser, timeout).until(
            lambda driver: EC.element_to_be_clickable((By.CSS_SELECTOR, locator))(shadow_root)
        )

    def wait_for_all_loaders_to_disappear(self, timeout: int = 9) -> None:
        try:
            WebDriverWait(self.browser, timeout).until(
                lambda driver: not self.are_any_loaders_present()
            )
            time.sleep(5)
        except TimeoutException:
            return None

    def are_any_loaders_present(self) -> bool:
        """Check with JS if any element is absolutely or fixed positioned with z-index > 0"""
        js_script = """
            var elements = document.querySelectorAll('*');
            for(var i = 0; i < elements.length; i++){
                var element = elements[i];
                var computedStyle = window.getComputedStyle(element);
                if(computedStyle.position == 'absolute' || computedStyle.position == 'fixed' ){
                  if(computedStyle.zIndex != 'auto' && parseInt(computedStyle.zIndex) > 0){
                    if(element.offsetParent != null){
                       return true
                    }
                   }
                 }
            }
        return false
        """
        return self.browser.execute_script(js_script)

    def open(self, url: str) -> None:
        self.browser.get(url)

    def wait_for_page_load(self, url: str) -> None:
        """
        Ждет загрузки страницы с указанным URL.
        :param url: URL страницы, которую нужно дождаться.
        """
        wait = WebDriverWait(self.browser, 10)
        wait.until(EC.url_to_be(url))

    def switch_to_window(self, page_number: int) -> None:
        self.browser.switch_to.window(self.browser.window_handles[page_number])

    # Возвращаем текущую страницу
    def get_current_url(self):
        return self.browser.current_url

    # Общий метод для получения атрибута элемента
    def get_attribute_of_element(self, element, attribute: str) -> str:
        return element.get_attribute(attribute)

    # Возвращает поле логин
    def get_login_input(self):
        return self.find_element(LocatorsAuth.LOGIN_INPUT)

    # Вводим логин
    def login_input_send_keys(self, login_pkg):
        self.wait_for_visible_and_clickable(LocatorsAuth.LOGIN_INPUT)
        self.get_login_input().send_keys(login_pkg)

    # Возвращает поле пароль
    def get_password_input(self):
        return self.find_element(LocatorsAuth.PASSWORD_INPUT)

    # Вводим пароль
    def password_input_send_keys(self, password_pkg):
        self.get_password_input().send_keys(password_pkg)

    # Вводим логин и пароль закупщика
    def login_and_password_purchaser(self):
        self.login_input_send_keys(self.login_pkg)
        self.password_input_send_keys(self.password_pkg)
        self.click_enter_button()

    # Вводим логин и пароль админа
    def login_and_password_admin(self):
        self.login_input_send_keys(self.login_admin)  # Обращаемся как к обычному атрибуту
        self.password_input_send_keys(self.password_admin)  # Обращаемся как к обычному атрибуту
        self.click_enter_button()

    # Вводим логин и пароль поставщика
    def login_and_password_supplies(self):
        self.login_input_send_keys(self.login_analytpribor)
        self.password_input_send_keys(self.password_analytpribor)
        self.click_enter_button()

    # Нажимаем кнопку "Войти" после ввода данных авторизации
    def click_enter_button(self):
        self.wait_for_visible_and_clickable(LocatorsAuth.ENTER_BUTTON)
        self.click_element(LocatorsAuth.ENTER_BUTTON)

    def get_current_date_string(self):
        """
        Возвращает сегодняшнее число, месяц и год в формате "DD.MM.YYYY".
        Например: "11.02.2025"
        """
        today = datetime.date.today()
        day = today.day
        month = today.month
        year = today.year

        return f"{day:02d}.{month:02d}.{year}"