UPLOAD_FILE_1_2 = r'"C:\Users\user\Downloads\Позиция 1.2.xlsx"'
RESPONSIBLE_LOGIN = 'Auto 3 QA'
