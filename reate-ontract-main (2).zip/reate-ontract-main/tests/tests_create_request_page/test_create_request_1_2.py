import allure


class TestCreatingApplication:
    @allure.title("Создание заявки с согласованием, сценарий 1.2")
    def test_creating_application(self, creating_application_setup):
        personal = creating_application_setup
