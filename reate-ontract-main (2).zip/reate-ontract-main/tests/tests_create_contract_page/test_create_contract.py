import allure
from pages.main_page import MainPage
from pages.create_contract_page import ContractBasicInformation, ContractBlockAttributes, \
    ContractBlockAdditionalAttributes, ContractBlockAgreement


class TestCreateContract:

    @allure.title("Тест на создание документа в КМ")
    def test_create_contract(self, browser):
        main = MainPage(browser)
        main.authorization()
        contract = ContractBasicInformation(browser)
        contract_block_basic_information = ContractBlockAttributes(browser)
        contract_block_additional_attributes = ContractBlockAdditionalAttributes(browser)
        contract_block_agreement = ContractBlockAgreement(browser)
        contract.click_button_create_documents()
        contract.block_basic_information()
        contract_block_basic_information.block_attributes()
        contract_block_additional_attributes.block_additional_attributes()
        contract.click_button_resume_page_document()
        contract.click_button_create_document_page_agreement()
        contract.click_button_to_send_page_agreement()
        contract_block_agreement.block_agreement_and_block_signing()
