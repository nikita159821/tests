import time

import allure

from pages.procedure_page import ProcedurePage
from pages.requirement_page import RequirementPage


class TestRequirement:
    @allure.title("Тест на создание процедуры")
    def test_create_procedure(self, browser, creating_application_setup):
        requirement = RequirementPage(browser)
        procedure = ProcedurePage(browser)
        expected_application_number = creating_application_setup
        requirement.choice_line_requirement(expected_application_number)
        procedure.choice_responsible_and_send_procedure()
        procedure.click_button_resume()
        procedure.click_remove_checkbox_docs()
        procedure.click_create_next_button()
        procedure.click_input_date_end()
        procedure.disable_approval_toggle()
        procedure.disable_project_approval_toggle()
        procedure.disable_publication_approval_toggle()
        procedure.send_keys_text_purchase_name()
        procedure.click_select_purchase_type_procedure()
        procedure.send_keys_text_planned_input()
        procedure.select_okpd2_category()
        procedure.send_keys_text_payment_terms()
        procedure.send_keys_text_delivery_terms()
        procedure.click_select_purchase_address_supplies()
        procedure.click_create_next_button_and_scroll()
        procedure.get_and_publish_trade()
        procedure.authorization_supplier()
        procedure.click_send_offer_button()
        procedure.click_form_save_button()
        procedure.choose_position_application()
        procedure.send_keys_text_price_value_input()
        procedure.save_position_and_submit_application()
        procedure.logout_lk()
        procedure.login_admin_procedure()
        procedure.edit_procedure()
        procedure.click_finish_accepting_applications_checkbox()
        procedure.click_save_changes_button()
        procedure.sign_in_purchaser_to_procedure()
        procedure.click_review_applications()
        procedure.click_coordination_confirm_changes()
        procedure.click_notice_tab_in_shadow_dom()
        procedure.click_create_results_button()
        procedure.choice_time_procedure()
        procedure.publish_result()
        procedure.click_create_document()
        time.sleep(1500)