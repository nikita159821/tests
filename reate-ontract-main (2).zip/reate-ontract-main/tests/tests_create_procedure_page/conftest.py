import time

import pytest
from selenium import webdriver
from selenium.webdriver.chrome.options import Options as ChromeOptions
from selenium.webdriver.firefox.options import Options as FirefoxOptions
from selenium.webdriver.common.keys import Keys

from locators.procedure_page_locators import LocatorsProcedure
from locators.requirement_page_locators import LocatorsRequirement
from pages.personal_account_page import PersonalPage
from pages.requirement_page import RequirementPage


@pytest.fixture(params=['chrome'])
def browser(request):
    browser_name = request.param
    if browser_name == "chrome":
        chrome_options = ChromeOptions()
        #chrome_options.add_argument("--headless=new")
        driver = webdriver.Chrome(options=chrome_options)
    elif browser_name == "firefox":
        firefox_options = FirefoxOptions()
        #firefox_options.add_argument("--headless")
        driver = webdriver.Firefox(options=firefox_options)
    else:
        raise ValueError(f"Unsupported browser: {browser_name}")

    driver.maximize_window()
    yield driver
    driver.quit()


@pytest.fixture
def creating_application_setup(browser):
    """Фикстура для создания заявки в личном кабинете и возврата URL."""
    personal = PersonalPage(browser)
    personal.authorize_iniciator_and_open_lk()
    personal.click_button_create_request()
    personal.click_button_list_positions()
    personal.click_button_upload_file()
    personal.upload_file_1_2()
    personal.click_button_send_approval()
    application_url = personal.save_url_application()
    personal.exit_lk()
    personal.click_button_approval()
    personal.click_button_approval_form()
    yield application_url


@pytest.fixture
def choice_responsible_and_send_procedure(browser):
    """Фикстура для отправки строки в процедуру и возврата URL страницы процедуры."""
    requirement = RequirementPage(browser)
    requirement.open_sidebar_and_choice_responsible()
    element = requirement.find_element(LocatorsRequirement.SCROLL_RESPONSIBLE)
    requirement.browser.execute_script("arguments[0].scrollIntoView(true);", element)
    requirement.wait_for_visible_and_clickable(LocatorsRequirement.RESPONSIBLE)
    requirement.click_element(LocatorsRequirement.RESPONSIBLE)
    # Получаем элемент поля ввода
    input_element = requirement.find_element(LocatorsRequirement.RESPONSIBLE)
    input_element.send_keys(Keys.CONTROL + "a")  # Выделяем все
    input_element.send_keys(Keys.DELETE)  # Удаляем все
    requirement.get_input_responsible().send_keys('QA Auto')
    requirement.click_element(LocatorsRequirement.CHOICE_RESPONSIBLE)
    requirement.sidebar_close()
    requirement.click_button_send_procedure()
    # ждем загрузки страницы с процедурой и сохраняем её
    requirement.wait_for_visible_and_clickable(LocatorsProcedure.BUTTON_RESUME)
    url_requirement_group_id = requirement.get_current_url()
    yield url_requirement_group_id
