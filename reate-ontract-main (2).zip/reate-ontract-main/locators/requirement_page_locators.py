from selenium.webdriver.common.by import By
from enum import Enum


class LocatorsRequirement(Enum):
    GET_NUMBER_APPLICATION = (By.XPATH, '//tbody[@class="cds-table__tbody"]/tr[2]/td[4]')
    GET_ACTUAL_NUMBER_APPLICATION = (By.XPATH, '//tbody[@class="cds-table__tbody"]//tr[2]/td[1]')
    OPEN_SIDEBAR = (By.XPATH, '//tbody[@class="cds-table__tbody"]/tr[2]/td[3]//div[@class="status-alert"]')
    SCROLL_RESPONSIBLE = (By.XPATH, '//div[@data-xid="requirement_info_sidebar_supplier_combobox"]')
    RESPONSIBLE = (By.XPATH, '//div[@data-xid="requirement_info_sidebar_supplier_combobox"]//input')
    CHOICE_RESPONSIBLE = (By.CSS_SELECTOR,'.cds-combobox__content .cds-list-item--clickable')
    CLOSE_SIDEBAR = (By.XPATH, '//button[@data-xid="requirement_info_sidebar_close_button"]')
    BUTTON_SEND_PROCEDURE = (By.XPATH, '//button[@data-xid="toolbar_create_procedure_button"]')
    ACTION_MENU = (By.XPATH, '//button[@data-xid="requirement-action-menu-activator"]')