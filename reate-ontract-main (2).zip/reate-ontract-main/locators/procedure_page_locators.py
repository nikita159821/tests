from selenium.webdriver.common.by import By
from enum import Enum


class LocatorsProcedure(Enum):
    BUTTON_RESUME = By.XPATH, ('//span[@class="cds-button__text" and contains(text(), "Продолжить")]/ancestor::button')
    CHOOSING_PURCHASE = By.XPATH, ('//*[@id="lflx"]')
    REMOVE_CHECKBOX = By.XPATH, '//input[@data-xid="offer-type-docs-checkbox"]/following-sibling::label/span[@class="cds-checkbox__label-text"]'
    CREATE_NEXT_BUTTON = By.XPATH, '//button[@data-xid="create-next-button"]'
    INPUT_DATE_END = By.XPATH, '//div[@data-xid="trade-date-end-datepicker"]'
    YEAR_BEGIN = (By.XPATH, '//div[@data-xid="trade-date-end-datepicker"]//input[@aria-label="Год"]')
    DATE_BEGIN_AND_YEAR_END = (
        By.XPATH, '//div[@data-xid="trade-date-end-datepicker"]//div[@class="dayContainer"]/span[1]')
    INPUT_PLANE_DATE_END = (By.XPATH, '//div[@data-xid="planned-stage-end-datepicker"]')
    PLANE_YEAR_BEGIN = (By.XPATH, '//div[@data-xid="planned-stage-end-datepicker"]//input[@aria-label="Год"]')
    PLANE_DATE_BEGIN_AND_YEAR_END = (
        By.XPATH, '//div[@data-xid="planned-stage-end-datepicker"]//div[@class="dayContainer"]/span[1]')
    TOGGLE_OFF_APPROVAL_PUBLICATION = (By.XPATH,
                                       '//input[@data-xid="publication-coordination-toggle"]/following-sibling::label/span[@class="cds-toggle__switch"]')
    TOGGLE_OFF_PROJECT_APPROVAL = (By.XPATH,
                                   '//input[@data-xid="trade-result-coordination-project-toggle"]/following-sibling::label/span[@class="cds-toggle__switch"]')
    TOGGLE_OFF_PUBLICATION_APPROVAL = (By.XPATH,
                                       '//input[@data-xid="trade-result-coordination-publish-toggle"]/following-sibling::label/span[@class="cds-toggle__switch"]')
    INPUT_PURCHASE_NAME = (By.XPATH, '//textarea[@data-xid="trade-subject-input"]')
    SELECT_PROCEDURE_TYPE = (By.XPATH, '//select[@data-xid="procedure-type-pgk-select"]')
    CHOOSING_TYPE_PROCEDURE = (By.XPATH, '//select[@data-xid="procedure-type-pgk-select"]/option[2]')
    PLANNED_INPUT = (By.XPATH, '//input[@data-xid="planned-cost-input"]')
    BUTTON_CLASSIFIER_CATEGORY = (By.XPATH, '//button[@data-xid="okpd-open-button"]')
    INPUT_SEARCH_CATEGORY = (By.XPATH, '//input[@data-xid="okpd-search-input"]')
    CHOOSING_CATEGORY = (By.XPATH, '//li[@data-xid="classifier-level-6-0"]')
    MODAL_CONFIRM_BUTTON = (By.XPATH, '//button[@data-xid="modal-confirm-button"]')
    INPUT_PAYMENT_TERMS = (By.XPATH, '//textarea[@data-xid="payment-terms-input"]')
    INPUT_DELIVERY_TERMS = (By.XPATH, '//textarea[@data-xid="delivery-terms-input"]')
    ADDRESS_SUPPLIES = (By.XPATH, '//select[@data-xid="address-select-0"]')
    ADDITIONAL_FIELD_NAME = (By.XPATH, '//input[@data-xid="additional-field-name-input-0"]')
    ALTERNATE_CHECKBOX = (By.XPATH, '//input[@data-xid="alternate-checkbox"]')
    TRADE_ID = (By.XPATH, '//div[@data-xid="trade-id"]')
    PUBLISH_TRADE_BUTTON = (By.XPATH, '//button[@data-xid="publish-trade-button"]')
    SEND_OFFER_BUTTON = (By.XPATH, '//button[@data-xid="send-offer-button"]')
    FORM_SAVE_BUTTON = (By.XPATH, '//button[@data-xid="form-save-button"]')
    POSITION_APPLICATION = (By.XPATH, '//td[@data-xid="position-1"]')
    PRICE_VALUE_INPUT = (By.XPATH, '//input[@data-xid="price-value-input"]')
    SAVE_POSITION_BUTTON = (By.XPATH, '//button[@data-xid="save-position-button"]')
    CLOSE_COOKIES = (By.CSS_SELECTOR, '.cds-button__appearance--primary:nth-child(2)')
    EXIT_BUTTON_LK = (By.XPATH, '//div[@class="core-header-auth"]/a[@class="cds-theme--b2b cds-link"]')
    SIGN_IN_BTN = (By.XPATH, '//button[@data-xid="sign-in-btn"]')
    SHOW_OFFER_PARTICIPANT_MODE_BUTTON = (By.XPATH, '//button[@dataxid="show-offer-participant-mode-button"]')
    LOGOUT = (By.XPATH, '//a[@class="header-auth__button cds-pa-none cds-link"]')
    HEADER_LOGIN_BUTTON = (By.XPATH, '//a[@data-xid="header-login"]')
    HEADER_LOGOUT = (By.XPATH, '//a[@data-xid="header-logout"]')
    EDIT_TRADE_BUTTON = (By.XPATH, '//button[@data-xid="edit-trade-button"]')
    OFFERS_FILTER_BTN = (By.XPATH, '//button[@data-xid="offers-filter-btn"]')
    LOCATOR_FINISH_ACCEPTING_APPLICATIONS_CHECKBOX = (
    By.XPATH, "//span[text()='Завершить прием заявок сейчас']/parent::label")
    SAVE_CHANGES_BUTTON = (By.XPATH, "//button[contains(., 'Сохранить изменения')]")
    BUTTON_POSITION = (By.XPATH, '//button[@data-xid="positions"]')
    LOGIN_LK = LOCATOR_LOGIN_BUTTON = (By.XPATH, "//span[text()='Войти']/ancestor::button")
    CREATE_OFFER_ADMITTANCES = (By.XPATH, '//button[@data-xid="create-offer-admittances"]')
    COORDINATION_CONFIRM_CHANGES = (By.XPATH, '//button[@data-xid="coordination-confirm-changes"]')
    CANCEL_OFFER_CONSIDERATION_BTN = (By.CSS_SELECTOR, 'button[data-xid="cancel-offer-consideration-btn"]')
    NOTICE_TAB_BUTTON = (By.CSS_SELECTOR, 'button[data-xid="view"]')
    CANCEL_OFFERS_CONSIDERATION_NOTICE = (By.CSS_SELECTOR, 'div[data-xid="cancel-offers-consideration-notice"]')
    TRADE_HEADER_WIDGET = (By.TAG_NAME, 'trade-header-widget')
    CREATE_RESULTS_BUTTON = (By.XPATH, '//button[@data-xid="create-results-button"]')
    START_DATE_PERIOD_BEGIN_LOCATOR = (By.XPATH, '//div[@data-xid="winner-start-date"]/div[@class="cds-inline-flex"]/div//input[@placeholder="дд.мм.гггг"]')
    END_DATE_PERIOD_BEGIN_LOCATOR = (By.XPATH, '//div[@data-xid="winner-start-date"]/div[@class="cds-inline-flex"]/div[2]//input[@placeholder="дд.мм.гггг"]')
    WINNERS_SELECT = (By.XPATH, '//div[@data-xid="winners-select"]')
    CREATE_DOCUMENT = (By.XPATH, "//span[text()='Создать документ']/parent::a")