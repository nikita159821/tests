from selenium.webdriver.common.by import By
from enum import Enum


class LocatorsBasicInformation(Enum):
    BUTTON_CREATE_DOCUMENTS = (
        By.XPATH, ']//button[@class="cds-theme--cds cds-button__appearance--primary cds-button__size--md cds-button"')
    INPUT_CONTRACTOR = (By.XPATH, '//div[@data-xid="combobox-choose-contactor"]/span/input[@id="lfmc"]')
    CHOICE_INPUT_CONTRACTOR = (
        By.XPATH, '//div[@data-xid="combobox-choose-contactor"]/div[@class="cds-combobox__options"]')
    DOCUMENT_TYPE = (By.XPATH, '//div[@data-xid="combobox-choose-document-type"]/span/input[@id="lfmd"]')
    CHOICE_DOCUMENT_TYPE = (By.XPATH,
                            '//div[@data-xid="combobox-choose-document-type"]/div[@class="cds-combobox__options"]/div[@title="Договор ПГК"]')
    PROCESS = (By.XPATH, '//div[@data-xid="combobox-choose-document-flow"]/span/input[@id="lfme"]')
    CHOICE_PROCESS = (By.XPATH, '//div[@data-xid="combobox-choose-document-flow"]/div[@class="cds-combobox__options"]')
    TEMPLATE_SUPPLIER = (By.XPATH, '//div[@data-xid="container-Шаблон поставщика"]')
    BUTTON_RESUME = (By.XPATH, '//button[@data-xid="bottom-navigation-submit"]')


class LocatorsBlockAttributes(Enum):
    NAME_DOCUMENT = (By.XPATH, '//input[@dataxid="base_attributes.title"]')
    PURCHASING_GROUP = (By.XPATH, '//div[@dataxid="base_attributes.purchase_group_id"]')
    CHOICE_PURCHASING_GROUP = (By.XPATH,
                               '//div[@dataxid="base_attributes.purchase_group_id"]//div[@class="cds-combobox__options"]/div[@title="101 ЦА_УЗ"]')
    PRICE_DOCUMENT_WITHOUT_VAT = (By.XPATH, '//input[@data-xid="base_attributes.price"]')
    PAYMENT_TERMS = (By.XPATH, '//div[@dataxid="base_attributes.payment_condition_id"]')
    CHOICE_PAYMENT_TERMS = (By.XPATH,
                            '//div[@dataxid="base_attributes.payment_condition_id"]//div[@class="cds-combobox__options"]/div[@title="РАП немедленно к оплате (ручной ввод)"]')
    VALUE_CURRENCY = (By.XPATH, '//div[@dataxid="base_attributes.currency"]')
    CHOICE_VALUE_CURRENCY = (By.XPATH,
                             '//div[@dataxid="base_attributes.currency"]/div[@class="cds-combobox__options"]/div[@title="Андоррская песета"]')
    DATE_BEGIN = (By.XPATH, '//div[@dataxid="base_attributes.date_begin"]//input[@id="lfmt-input-1"]')
    YEAR_BEGIN = (By.XPATH, '//div[@dataxid="base_attributes.date_begin"]//input[@aria-label="Год"]')
    DATE_BEGIN_AND_YEAR_END = (
        By.XPATH, '//*[@id="date_begin"]//div[@class="flatpickr-days days"]/div[@class="dayContainer"]/span[1]')
    DATE_END = (By.XPATH, '//div[@dataxid="base_attributes.date_end"]//input[@id="lfmu-input-1"]')
    YEAR_END = (By.XPATH, '//div[@dataxid="base_attributes.date_end"]//input[@aria-label="Год"]')
    DATE_END_AND_YEAR_END = (
        By.XPATH, '//*[@id="date_end"]//div[@class="flatpickr-days days"]/div[@class="dayContainer"]/span[1]')
    CHOICE_YEAR_END = (By.XPATH, '//div[@dataxid="base_attributes.date_end"]//input[@class="numInput cur-year"]')
    BUTTON_RESUME_PAGE_ATTRIBUTES = (By.XPATH, '//button[@data-xid="bottom-navigation-submit"]')


class LocatorsBlockAdditionalAttributes(Enum):
    TYPE_AGREEMENT = (By.XPATH, '//div[@dataxid="extra_attributes.contract_kind_code"]')
    CHOICE_TYPE_AGREEMENT = (By.XPATH, '//div[@dataxid="extra_attributes.contract_kind_code"]//div[@title="Расходный"]')
    AUTO_RENEWAL_CATEGORY_CODE = (By.XPATH, '//div[@dataxid="extra_attributes.auto_renewal_category_code"]')
    CHOICE_AUTO_RENEWAL_CATEGORY_CODE = (By.XPATH,
                                         '//div[@dataxid="extra_attributes.auto_renewal_category_code"]//div[@class="cds-combobox__options"]/div[@title="N - Нет"]')
    RCM_TYPE_SUMM = (By.XPATH, '//div[@dataxid="extra_attributes.rcm_type_summ"]')
    CHOICE_RCM_TYPE_SUMM = (By.XPATH,
                            '//div[@dataxid="extra_attributes.rcm_type_summ"]/div[@class="cds-combobox__options"]//div[@title="D - Точная сумма"]')
    RCM_SIGN_PLACE = (By.XPATH, '//input[@dataxid="extra_attributes.rcm_sign_place"]')
    CHOICE_IS_FIXED_CURRENCY = (
        By.XPATH, '//div[@dataxid="extra_attributes.is_fixed_currency"]//div[@class="cds-radio-button__item"]')
    CONTRACT_CATEGORY_CODE = (By.XPATH, '//div[@dataxid="extra_attributes.contract_category_code"]')
    CHOICE_CONTRACT_CATEGORY_CODE = (By.XPATH,
                                     '//div[@dataxid="extra_attributes.contract_category_code"]/div[@class="cds-combobox__options"]//div[@title="PDPD - Прочие договоры"]')
    RCM_SUB_CATEG = (By.XPATH, '//div[@dataxid="extra_attributes.rcm_sub_categ"]')
    CHOICE_RCM_SUB_CATEG = (By.XPATH,
                            '//div[@dataxid="extra_attributes.rcm_sub_categ"]/div[@class="cds-combobox__options"]//div[@title="PDPD - Прочие договоры"]')
    BUSINESS_AREA_CODE = (By.XPATH, '//div[@dataxid="extra_attributes.business_area_code"]')
    CHOICE_BUSINESS_AREA_CODE = (By.XPATH,
                                 '//div[@dataxid="extra_attributes.business_area_code"]/div[@class="cds-combobox__options"]//div[@title="1001 - Центральный Аппарат"]')
    FINANCIAL_MANAGEMENT_POSITION = (By.XPATH, '//div[@dataxid="extra_attributes.financial_management_position"]')
    CHOICE_FINANCIAL_MANAGEMENT_POSITION = (By.XPATH,
                                            '//div[@dataxid="extra_attributes.financial_management_position"]/div[@class="cds-combobox__options"]//div[@title="100100000 - ЦА"]')

    ACTIVITY_CATEGORY = (By.XPATH, '//div[@dataxid="extra_attributes.activity_category"]')
    CHOICE_ACTIVITY_CATEGORY = (By.XPATH,
                                '//div[@dataxid="extra_attributes.activity_category"]/div[@class="cds-combobox__options"]//div[@title="10100001 - Оперирование"]')
    CHOICE_RCM_SUBS_ID = (
        By.XPATH, '//div[@dataxid="extra_attributes.rcm_subs_id"]//div[@class="cds-radio-button__item"]')
    HOUSE_BANK = (By.XPATH, '//div[@dataxid="extra_attributes.house_bank"]')
    CHOICE_HOUSE_BANK = (By.XPATH,
                         '//div[@dataxid="extra_attributes.house_bank"]/div[@class="cds-combobox__options"]//div[@title="GPB01 - Банк ГПБ (АО)"]')
    ACCOUNT_DETAILS_ID = (By.XPATH, '//div[@dataxid="extra_attributes.account_details_id"]')
    CHOICE_ACCOUNT_DETAILS_ID = (By.XPATH,
                                 '//div[@dataxid="extra_attributes.account_details_id"]/div[@class="cds-combobox__options"]//div[@title="RP319 - Расчетный ГПБ RUB"]')
    RCM_ACT_PERIOD = (By.XPATH, '//div[@dataxid="extra_attributes.rcm_act_period"]')
    CHOICE_RCM_ACT_PERIOD = (By.XPATH,
                             '//div[@dataxid="extra_attributes.rcm_act_period"]/div[@class="cds-combobox__options"]//div[@title="Ежегодно"]')
    BUTTON_RESUME_PAGE_ADDITIONAL_ATTRIBUTES = (By.XPATH, '//button[@data-xid="bottom-navigation-submit"]')
    BUTTON_RESUME_PAGE_DOCUMENT = (By.XPATH, '//button[@data-xid="bottom-navigation-submit"]')
    BUTTON_CREATE_DOCUMENT_PAGE_AGREEMENT = (By.XPATH, '//button[@data-xid="bottom-navigation-submit"]')
    BUTTON_TO_SEND_PAGE_AGREEMENT = (By.XPATH, '//button[@data-xid="create-document-sidebar-send-button"]')


class LocatorsAgreement(Enum):
    BLOCK_AGREEMENT = (By.XPATH, '//button[@data-xid="document-primary-button-document_send_new_to_sap"]')
    BUTTON_REQUEST_WEB_SERVICE = (By.XPATH, '//button[@type="submit"]')
    BUTTON_APPROVE_DOCUMENT = (By.XPATH, '//button[@data-xid="document-primary-button-document_approve_by_contractor_auto_send_to_inner_approval"]')
    BUTTON_SEND = (By.XPATH, '//div[@data-xid="sidebar-document-approve-by-contractor"]//button[@class="cds-button cds-button__primary cds-button__size--md"]')