from selenium.webdriver.common.by import By
from enum import Enum


class LocatorsAuth(Enum):
    INPUT_SEARCH_ORGANIZATION = (By.XPATH, '//*[@id="companies-search-field"]')
    COMPANY_PGK = (By.XPATH, '//a[@href="/firms/publichnoe-aktsionernoe-obshchestvo-pervaia-gruzovaia-kompaniia/363877/"]')
    LOGIN_BUTTON = (By.XPATH, '//div[@class="core-header__actions"]')
    LOGIN_BUTTON_2 = (By.XPATH, '//div[@class="lg:cds-block cds-none"]')
    LOGIN_INPUT = (By.ID, 'login_control')
    PASSWORD_INPUT = (By.ID, 'password_control')
    ENTER_BUTTON = (By.XPATH, '//*[@id="enter_button"]')
    EXIT_BUTTON = (By.XPATH, '//div[@class="core-header-auth"]/a[@class="cds-theme--promo cds-link"]')


class LocatorsLk(Enum):
    LK_BUTTON = (By.XPATH, '//div[@class="header-account gt-lg"]')
    BUTTON_CREATE_REQUEST = (By.ID, 'create_regular_procedure_request_button')
    BUTTON_LIST_POSITIONS = (By.XPATH, '//a[contains(text(),"Список позиций")]')
    BUTTON_UPLOAD_FILE = (By.CSS_SELECTOR, ".cds-ml-m:nth-child(2)")
    BUTTON_SEND_APPROVAL = (By.XPATH, '//form[@class="cds-form"]/button[2]')
    BUTTON_SEND = (By.CSS_SELECTOR, ".cds-modal__footer > .cds-button__primary")
    EXIT_BUTTON_LK = (By.XPATH, '//a[@class="hidden-mobile"]')
    BUTTON_APPROVAL = (By.XPATH, '//form[@class="cds-form"]//button[contains(@class, "cds-button__primary")]')
    BUTTON_APPROVAL_FORM = (By.XPATH, '//footer[@class="cds-modal__footer"]//button[contains(@class, "cds-button__primary")]')